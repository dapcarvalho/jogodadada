# Jogo da Velha (Tic-Tac-Toe) - Tutorial (pronto para GitHub)

Este repositório contém uma versão pronta do **Jogo da Velha** baseada no tutorial oficial do React,
empacotada num único arquivo `index.html` que usa React + JSX via CDN. Basta abrir `index.html` no navegador.

## Arquivos
- `index.html` — App React pronto (abra no navegador).
- `README.md` — este arquivo.
- `LICENSE.txt` — MIT.

## Como abrir localmente
1. Baixe/clon e abra `index.html` no seu navegador (Chrome/Firefox). Como o código usa bibliotecas via CDN, **não** é necessário instalar dependências.
2. Se preferir rodar um servidor local (recomendado para evitar problemas de CORS), use, por exemplo:
   - Python 3: `python -m http.server 8000` (na pasta onde está `index.html`) e abra `http://localhost:8000`.

## Como criar um repositório no GitHub e enviar (push) este projeto
1. Crie um novo repositório no GitHub (por exemplo `tic-tac-toe-daphne`).
2. No seu computador, copie os arquivos desta pasta para uma pasta local `tic-tac-toe-github`.
3. Abra o terminal na pasta e rode:

   ```bash
   git init
   git add .
   git commit -m "Adicionar jogo da velha (tutorial React) pronto"
   git branch -M main
   git remote add origin https://github.com/SEU_USUARIO/NOME_DO_REPOSITORIO.git
   git push -u origin main
   ```

   Substitua `SEU_USUARIO` e `NOME_DO_REPOSITORIO` pelos seus dados do GitHub.

## Dicas
- Se quiser transformar em um app React profissional (com `create-react-app` ou Vite), eu posso fornecer os passos e arquivos `package.json` apropriados.
- Se quiser que eu gere o repositório no GitHub para você, eu não tenho acesso à sua conta nem permissão para criar repositórios — eu posso, no entanto, fornecer os comandos e arquivos prontos (que é o que está aqui).

## Autor
Arquivo gerado automaticamente por assistente — entregue ao usuário para subir ao próprio repositório.
